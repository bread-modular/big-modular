# Big Modular — PD-only power module / A3 shallow-stack placement WIP

**INCOMPLETE / NON-OPERATIONAL / DO NOT FABRICATE OR CONNECT VALUABLE LOADS.**

This revision is a connected circuit proposal, not a working power module. Explicit 9 V PDO/current validation, input ESD/surge protection, four USB footprint clearances, exact mechanical hardware/actuator selection and the complete electrical PCB layout remain blocking. The A3 panel uses simple off-centre round rail holes on the common fixed-strip grid phase; sliding nuts are no longer required. A1 WIP was merged into main; its merge does not imply fabrication approval. This review does not commit or merge.

## Deliverables

- `hardware/big_modular.kicad_sch`: **A4 navigation overview plus three A3 functional subsheets**: input/protection, power conversion, output rails. All 88 real components and their electrical connectivity are retained; local feedback/filter/protection branches now use visible wires.
- [`docs/schematic.pdf`](docs/schematic.pdf): **four navigable pages** (overview + three circuit pages), exported from the root hierarchy.
- [Sheet guide](docs/schematic-guide.md): page map, signal flow and manual-reading notes. [Component guide](docs/component-guide.md): what each main component/support network does, how and why. [Readability validation](reports/schematic-readability.md): unchanged connectivity and remaining check limitations.
- `hardware/big_modular.kicad_pcb`: perpendicular carrier reduced from **60 to 30 mm depth envelope**. Original USB J1 is unchanged; J3/J4 add right-angle socket placement reservations.
- `hardware/middle_plate.kicad_pcb`: new **8.8 × 100.5 mm** control PCB with front-facing power LED, series-resistor and tactile-reset footprints; rear straight 2.54 mm headers mate with the carrier sockets.
- `hardware/front_panel.kicad_pcb`: retained **2HP, 9.8 × 128.5 × 1.6 mm** panel, LED window and reset access hole, four M3 support holes. **Round left-corner rail holes at X2.42** are one 5.08mm pitch left of X7.50; check screw-head clearance to the neighbouring panel.
- [`docs/assembly.svg`](docs/assembly.svg) / [`assembly.pdf`](docs/assembly.pdf): dimensioned front/middle/side/header views. Four **10 mm M3 supports** accept 6mm male studs or 10mm spacers. Four open side-access bays keep nuts reachable with the carrier soldered and mated; use a 5.5AF open-ended spanner **out of the rack**. The two small transverse brace bolts remain M2, not the panel standoffs. See [`mechanics.md`](docs/mechanics.md) for research, pin mapping, fasteners, assembly and limitations.
- [M3 nut-access drawing](docs/m3-access.pdf): hardware options, complete thread stacks and side-entry tool clearance. Body, nut and wrench limits are specified in the mechanical guide; actual user parts still need a fit trial.
- `hardware/mechanics/corner_braces.scad`: original fit-prototype source. The external reset actuator remains undecided; only its panel hole and switch footprint are reserved.
- `BOM.csv` and schematic circuit remain unchanged at **88 real components**. [`docs/interface-placement.csv`](docs/interface-placement.csv) separately records new **PCB-only** UI/header/hardware candidates; these are not working or schematic-integrated parts.
- [A3 validation](reports/stack-validation.md), source preservation hashes and native ERC/DRC/parity reports in `reports/stack-a3-native/`. Existing schematic readability evidence remains in `reports/readability-native/`; `reports/validation-summary.md` is historical A1 evidence.

**All three boards retain zero tracks, zero vias and zero zones.** Do not synchronize
from the full schematic or route to hide intentional incompleteness. New UI/reset
nets are isolated reservations, not a functional reset circuit. The PCB rear edge
is **30.4 mm behind the panel**; the drawn cable budget to Z=50 is unqualified,
so this is not a promised finished-module depth or fabrication-ready stack.

## Circuit and power permission

```
USB-C -> fuse -> TPS26600 HARD GATE -> TPS62160 4.016 V
                ^                       -> TPS65131 +/-13.95 V
 CH224K PG -> Q1 -> RUN                    -> +/-12 V LDOs
                AND UV/OV window           -> TPS62125 ~+6.5 V -> +5 V LDO
                                                               -> off-board 16-pin J2
```

CH224K requests 9 V with CFG1=6.8k; CFG2/3 float. Its DP/DM are shorted locally and isolated from USB data, selecting PD-only protocol use. **5 V VBUS is retained only for negotiation housekeeping; there is no 5 V-input rail-output mode.**

- R4/R5 now set nominal UV rising **7.878 V**; OVP remains **10.781 V**. Hardware rejects 5 V even with RUN closed and PG asserted; sustained 15/20 V is outside the window.
- Active-low PG drives PNP Q1, which supplies SHDN through **series** JP1 RUN. R30 pulls SHDN low by default. RUN cannot bypass the PG gate or window. R31 bleeds off-state VPROT leakage. All converter bulk is downstream of the eFuse; upstream C1/C2 are housekeeping bypass only.
- **PG + voltage qualification is NOT proven explicit-PD-contract/current qualification.** WCH's generic PG specification does not attest a 9 V fixed PDO or sufficient negotiated current. Under a compliant-source assumption this is a useful hard interlock, but the strict contract-qualified requirement remains an explicit fabrication blocker. A 9 V DC reading alone is insufficient; no cryptographic authentication is claimed.
- No loads until independent PD analysis verifies a fixed 9 V contract with at least 0.5 A authorization and the outstanding design blockers are cleared. Only provisional simultaneous **~40 mA on each rail** is proposed for initial tests; no continuous/peak output rating exists.

The eFuse setting is 0.2985 A **nominal**, not a guaranteed input bound at this low setting and not a rail rating. About 1.16 W output and 2.26 W converter input at the provisional loads are estimates; housekeeping/inrush and thermal margins are unverified. +5 V shares the positive boost budget. Approximately ±13.95/+6.5 V preregulation is retained, subject to dropout, ripple, stability and actual-part checks. U5's 6.52 V divider-selection target uses 0.800 V; its 0.808 V typical reference predicts about 6.585 V. U3 PG sequences normal startup but is high-impedance in shutdown/UVLO, not a guaranteed fault latch; see the component guide.

## Precedent, differences and limitations

Andreas Dorfner's **Powerline USB-C** is a published **3HP / 20 V** PD Eurorack design, licensed CERN-OHL-P v2. Its schematic leaves CH224K PG unconnected and feeds regulator VINs directly from VBUS; that startup approach was **not copied**. We use its front-entry/two-support-point assembly idea as a reference only, retain our perpendicular 2HP geometry, and add a PG/window gate. No third-party CAD/artwork/datasheets are delivered. This is not a claim that the 3HP design proves our 2HP fit or performance. [source](https://github.com/Andreas-Dorfner/Powerline-USB-C) [source](https://github.com/Andreas-Dorfner/Powerline-USB-C/blob/main/LICENSE.md)

The unsafe D1 TVS stays absent: there is **no qualified VBUS/CC ESD or hot-plug surge solution**. No output precision OVP, all-rail fault latch, tracking, guaranteed discharge, thermal/EMI qualification or plug/cable fit certification exists. TPS62125 PFM/up-to-1MHz operation still does not meet an always-MHz requirement. See `docs/design-review.md` and `docs/test-matrix.md`.

## Shared KiCad tools and part sourcing

Use the local [portable KiCad toolkit](opt/kicad-tools/README.md) first for native
checks, candidate edits, exports, catalog lookup, BOM audits and passive sourcing.
It was copied independently from Bread Modular; no source checkout is needed at
runtime. [Project workflow and safety rules](Code.md) are also linked from
[AGENTS.md](AGENTS.md), and both workflow/sourcing skills are discoverable under
`.agents/skills/`.

```sh
python3 -B opt/kicad-tools/kicad_tools.py --help
python3 -B opt/kicad-tools/kicad_tools.py doctor --config tools/kicad-project.json
python3 -B opt/kicad-tools/kicad_tools.py assembly --help
python3 -B -m unittest discover -s tests -v
```

See [setup, provenance and exact sourcing/check commands](docs/kicad-tooling.md).
The explicit profile selects the carrier, not the mechanical panel. Full PCB
parity is intentionally incomplete; do not synchronize or route any board to
make a generic check pass. Use the A3 mechanical candidate builder only for an explicitly scoped placement change. Root `BOM.csv` is a design inventory, not the grouped
assembly BOM expected by the auditor. Optional routing controllers are included
**without runtimes**. Setup does not change hardware or establish release approval.

## Regeneration / checks

Installed engine used: KiCad 10.0.6. `tools/build_project.py` owns the circuit inventory; `tools/render_schematic.py` owns the three-subsheet hierarchy/layout; `tools/stack_geometry.py` and `tools/build_stack.py` own the A3 placement contract/candidate; `tools/build_mechanics.py` owns the original assembly drawing. Generate **new candidates** and validate before copying reviewed deliverables. The unflagged legacy full builder is disabled so it cannot restore the old deep boards. No research download is needed to regenerate.

```sh
# Mechanical/placement work (does not touch schematics or root BOM):
/usr/bin/python3 -B tools/build_stack.py --output research/new-stack-candidate
python3 -B tools/build_mechanics.py --output research/new-assembly-candidate
/usr/bin/python3 -B tools/verify_stack.py --hardware research/new-stack-candidate/hardware --geometry research/new-stack-candidate/assembly-geometry.json
# Review candidate drawings/native DRC, then copy only approved outputs.
# Separately, for schematic-only work:
python3 -B tools/build_project.py --schematic-only --output research/new-schematic-candidate
# Review/validate the candidate, then copy only its four schematic files into hardware/.
# The remaining commands validate/export the delivered hardware/ hierarchy.
kicad-cli sch erc hardware/big_modular.kicad_sch --severity-all -o reports/erc.rpt
kicad-cli sch erc hardware/big_modular.kicad_sch --severity-all --format json -o reports/erc.json
kicad-cli sch export pdf hardware/big_modular.kicad_sch --draw-hop-over -o docs/schematic.pdf
kicad-cli sch export netlist hardware/big_modular.kicad_sch -o reports/big_modular.net
kicad-cli pcb drc hardware/big_modular.kicad_pcb --severity-all --format json -o reports/carrier-drc.json
kicad-cli pcb drc hardware/front_panel.kicad_pcb --severity-all --format json -o reports/panel-drc.json
kicad-cli pcb drc hardware/middle_plate.kicad_pcb --severity-all --format json -o reports/middle-drc.json
/usr/bin/python3 tools/verify_project.py
pdfinfo docs/schematic.pdf
git diff --check
```

ERC cleanliness is not proof of function. The separate per-board DRC reports omit schematic parity/refill; the A3 common-tool private check additionally retains full carrier schematic parity and refill-in-memory findings. The generated whole-net audit is not independent; the verifier additionally hardcodes 65 pin/net spot checks, traverses 20 wire/hierarchy interstage paths and 57 local wire paths, retains one documented named PRE_P continuation, and checks actual PCB geometry including 16 NPTHs, seven board-to-board mating pin axes and four side-entry M3 tool envelopes with obstruction-negative tests. A native before/after audit retains all 288 exported pin memberships, including no-connect/singleton nets. Private isolated ERC retains 68 pre-existing footprint-library configuration warnings; installed-environment ERC reports zero. No rules were suppressed. User rail continuous/peak targets are still required before any output rating can be designed.
