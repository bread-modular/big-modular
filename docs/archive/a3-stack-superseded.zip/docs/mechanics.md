# A3 — corner rail holes, 10 mm M3 supports and accessible nuts

**Placement / fit proposal only. No routing, working LED/reset circuit or fabrication approval.**

See [assembly.pdf](assembly.pdf) / [assembly.svg](assembly.svg), and the enlarged
[M3 access drawing](m3-access.pdf) / [SVG](m3-access.svg). Dimensions are nominal mm.
The [geometry contract](assembly-geometry.json) matches all three native PCB files.

## Changes requested in this pass

- Replace A2's centred rack slots with **two simple round left-corner holes**, like
  the supplied example. Sliding nuts are **no longer a design requirement**.
- Replace the four front-to-middle M2 supports with **M3, 10 mm clear body length**.
  Accommodate the user's **6 mm male thread**, or **10 mm spacers**.
- Keep the nuts accessible **after the carrier sockets are soldered AND plugged
  into the middle board**: four open side-entry wrench bays, not a requirement to
  tighten inaccessible nuts before soldering.
- Move the middle PCB back 4 mm and the carrier socket rows back 4 mm to preserve
  mating. Move upper connector row 1 mm upward and reposition support/brace holes.
- Keep the USB footprint and its assembly position, LED window and reset hole.
  Keep the **30 mm carrier depth envelope / rear edge Z32**; no extra rear depth.

## Rack mounting — the simple corner pattern

Panel: **9.8 × 128.5 × 1.6 FR4**. Rail holes are **Ø3.2** at:

| Hole | X from left | Y from top |
|---|---:|---:|
| Top | 2.42 | 3.0 |
| Bottom | 2.42 | 125.5 |

Doepfer gives the 5.08 mm horizontal pitch and 9.8 mm actual 2HP width. The
left-corner location here is **7.50 − 5.08 = 2.42**: one whole pitch left of the
usual 7.50 position, therefore the **same threaded-strip grid phase**, not the
half-pitch shift caused by A2's centre slots. The supplied photo establishes the
requested visual arrangement, not exact dimensions of that commercial panel.
[source](https://doepfer.de/a100_man/a100m_e.htm)

Round holes do not inherently require sliding nuts when the panel follows the
rail's pitch/phase. This design targets common Doepfer-phase fixed strips and
also accepts sliding nuts; it is not a promise for different-phase rail systems.
[source](https://sdiy.info/wiki/Eurorack_parts)

The hole leaves **0.82 mm FR4 web** at the left edge. A 6 mm rail screw head
nominally overhangs that edge by **0.58 mm**; check adjacent-panel clearance.
A head/washer diameter **≤4.6 mm** stays nominally within the panel. This is a
screw-head/FR4 fit consideration, **not** a reason to require sliding nuts again.
No countersink is cut into the 1.6 mm FR4. Use the screw thread/length appropriate
to the actual rail; internal support nuts and rail nuts are separate hardware.

## Front-to-middle support hardware

Four common **Ø3.2** NPTHs: **X4.9**, **Y17.5 / 50 / 78.5 / 111**.
The front panel rear is Z1.6; the middle front is Z11.6 and rear Z13.2.
The support body provides **10 mm between boards**, not 10 mm overall including
its thread. All screws/nuts are manual hardware, not an electronics assembly BOM.

The user's exact body shape, OD, internal thread depth and tool were not supplied.
Design limits are **hex body ≤6 mm across flats** or **round body ≤7 mm OD**;
M3 plain hex nut **≤5.5 mm AF, ≤2.4 mm high**; rear washer **≤7 mm OD, 0.5 mm thick**.
ISO 4032 dimensions support that plain-M3-nut envelope; larger/flanged/nyloc nuts
are **not** interchangeable within this calculation.
[source](https://www.fasteners.eu/standards/iso/4032/)

### Option A — user's M3 10+6 male/female standoffs

- Female end toward front panel; **M3×6 front screw** through 1.6 mm panel gives
  **4.4 mm engagement**. Require at least **5 mm usable tapped depth**, including
  allowance for thread runout; measure the actual part before choosing screws.
- **6 mm stud points rearward**, through the middle PCB. Rear washer and M3 nut
  remain accessible from the side with the fully mated carrier in place.
- At Y17.5/111: `6 − 1.6 PCB − 0.5 washer − 2.4 nut = 1.5 mm` visible stud.
- At Y50/78.5: add **1.0 mm brace seat**, leaving **0.5 mm** beyond the full nut.
  Do **not** reuse A2's 2 mm brace flange: it consumes the required thread length.
- Stud tip Z17.6. No thread cutting, jammed double nuts or blind bottoming assumed.

### Option B — 10 mm unthreaded spacers

Use a spacer with an M3 clearance bore, **fully threaded M3×18** from the front,
then the same rear washer/nut. The board gap stays 10 mm.

| Position | Panel + spacer + PCB + brace + washer + nut | Thread beyond nut |
|---|---:|---:|
| End supports | 1.6 + 10 + 1.6 + 0 + 0.5 + 2.4 = 16.1 | 1.9 |
| Brace supports | 1.6 + 10 + 1.6 + 1 + 0.5 + 2.4 = 17.1 | 0.9 |

Tip Z18.0 remains ahead of the carrier's recessed Z20.5 edge. Do not substitute
longer bolts without recalculating their tip envelope. Hold the rear nut with the
side spanner and turn the front screw.

### If “spacers” means 10 mm female/female threaded pillars

Use M3×6 at the panel, M3×6 at the middle end supports and M3×8 through the brace
positions, with the same 0.5 mm rear washer. Nominal opposing screw-tip gaps are
**1.7 mm at ends / 0.7 mm at braces**. Require ≥5 mm usable tapped depth at both
ends; these are fit targets, not a guarantee about unknown parts. No rear nuts
are necessary in this variant.

## Nut access with the main PCB already soldered

**Service the module out of the rack.** This design does not promise spanner
access between installed adjacent modules, or straight rear socket-driver access.

- Approach from the **right (+X)** with a **5.5 mm open-ended spanner**.
- Reserve a tool-head envelope **12 mm wide in Y × 3 mm thick in Z**, plus a
  clear side-entry handle corridor. Actual wrench silhouette must fit that
  envelope; a socket marked “5.5” does not establish its outside diameter.
- Four carrier front-edge bays extend back to **Z20.5**. Their Y intervals are
  **14..24**, **43.5..56.5**, **72..85**, **104.5..114.5**.
- M3 nut seats are Z13.7 at ends and Z14.7 at braces; tool Z envelopes are
  **13.7..16.7 / 14.7..17.7**. The carrier behind the bays and both soldered/mated
  connector rows are outside these envelopes. Nominal bay-side margin is ≥0.5 mm.
- The brace uprights are offset away from the nut lanes. No closed access tube,
  buried nut, de-soldering or unplugging of the main board is needed for this
  **nominal** wrench path. Hold the standoff body in the 10 mm gap if necessary.
- The tool temporarily extends beyond the 2HP width, which is why service must be
  out of the rack. These are **drawing-only mechanical reservations**, not KiCad
  copper keepout zones. Preserve them during later component placement/routing.

`tools/m3_fit.py` checks swept tool boxes, rotating nut/washer envelopes, spacer
bodies and worst bolt tips against the **verified native carrier outline**, both
mated/soldered header envelopes and both brace solids. Negative tests reintroduce
a blocked carrier, a too-narrow wrench bay, an obstructing header and an oversized
tool. A passing calculation is **not** a physical tool-fit or tolerance test.

## Carrier support and brace limits

The two **panel standoffs at Y50 / Y78.5 are M3**. They also clamp new open-sided
corner-brace feet behind the middle. Each foot is 1 mm thick so a 6 mm stud can
engage a complete M3 nut with the specified washer. The previous closed brace
body would block the new nut/wrench; it is not reused.

The **two transverse carrier brace bolts remain M2×8**, not M2 standoffs. This
keeps the narrow perpendicular PCB's existing low-profile side-fastener envelope:
head ≤1.2 mm high / ≤3.8 diameter; captive M2 nut ≤4 AF / ≤1.6 thick. The four
panel-to-middle supports are all M3; this pass does **not** claim all-M3 hardware.

| Brace feature | Upper | Lower |
|---|---|---|
| M3 support Y | 50 | 78.5 |
| Foot Y range | 37..54 | 74.5..92.5 |
| Upright Y range | 37..43 | 86.5..92.5 |
| Transverse M2 hole (Y,Z) | (40,25.2) | (89.5,25.2) |

Foot X0.5..9.3 / Z13.2..14.2; upright X3.17..8.97 / Z14.2..30.5.
M2 nut pockets X7.17..8.97. Insert those captive nuts from the open right face;
side bolts are driven from the left, out of the rack. Two existing rear Ø2.2 tie
holes at (45,28)/(83.5,28) remain optional, not panel/standoff holes.

[corner_braces.scad](../hardware/mechanics/corner_braces.scad) is an original
**fit-prototype source**, not an exported or print-tested structural part.
OpenSCAD is not installed here, so no solid/mesh/print validation was performed.
The 1 mm foot is a significant strength/creep limit: test material, print layers,
nut load, USB insertion/cable torque and FR4 bearing. Do not equate M3 thread size
with a stronger printed support. A revised material/brace may be needed after a
mock-up. Intended load path remains USB stakes → carrier → braces → M3 supports
→ panel, rather than relying on connector solder joints alone.

## Native coordinates and electrical placement

Panel front Z0, rear Z1.6; X right, Y down, Z into case. All boards are 1.6 thick.

| Feature | Assembly coordinates / transform |
|---|---|
| Front panel | KiCad (x−50,y−30) → (X,Y) |
| Middle | KiCad (x−80,y−30) → (X,Y); front Z11.6 / rear Z13.2 |
| Carrier | B.Cu X1.57 / F.Cu X3.17; Y=x_KiCad−35.75, Z=104.275−y_KiCad |
| USB mouth axis | (4.9,64.25,0.8), insertion +Z |
| USB opening | X2.725..6.925 / Y59.35..69.15; 4.2×9.8 R0.6 |
| Middle notch | X0.5..7.2 / Y56.5..72; retained 2.1 mm right-hand spine |
| LED / reset centres | X4.9; Y38 / Y91; Ø2.4 / Ø3.2 panel openings |
| Header contact X | 4.44 = carrier F.Cu 3.17 + 1.27 contact height |
| Male back body | Z13.2..15.74; pins point into case |
| Female socket mouth / pad row | Z15.74 / Z25.77; opens toward panel |

J1 native object, position (100,99.8), rotation, footprint, UUIDs, pad geometry,
net names and model are unchanged. Its four existing hole-clearance violations
remain unwaived. The retained USB footprint basis is from the GCT drawing; actual
plug overmould, tolerances and insertion force still need trials.
[source](https://gct.co/files/drawings/usb4105.pdf)

| Mating pair | Pin axes Y | Isolated reservation pinout |
|---|---|---|
| J3 carrier / J5 middle, 1×4 | 26, 28.54, 31.08, 33.62 | UI_P5_PENDING, UI_GND_PENDING, UI_GND_PENDING, UI_P5_PENDING |
| J4 carrier / J6 middle, 1×3 | 96, 98.54, 101.08 | RESET_A_PENDING, RESET_B_PENDING, spare |

2.54 mm pitch; right-angle female sockets on carrier F.Cu, straight males on
middle B.Cu. The flipped male footprint uses 180° rotation so numbered pins
actually align. Generic envelopes are not an approved mating-part selection;
check engagement, real contact height and plating. Trim carrier tails to ≤2.7 mm
from F.Cu with ≤0.2 mm additional solder envelope. J3/J5 moved together in Y; both
carrier sockets moved 4 mm in Z to match the new spacing.

D10/R32/SW1/J3–J6 stay **PCB-only** reservations outside the unchanged 88-component
schematic/BOM. D10/R32 are an eventual +5 V indicator branch, not proof of all
rails or PD health. The 2.2k value, LED MPN and optional light pipe remain pending.
The LED is now 4 mm deeper behind its unchanged window; trial visibility/light
pipe rather than assume it will be bright enough.

SW1 retains the KMR2 normally-open tactile candidate. With its nominal 1.9 mm
height, actuator tip moves to **Z9.7**. The Ø3.2 panel hole is retained; **no printed
plunger has been selected**. Future stem length needs actual travel/idle clearance,
retention and an overtravel stop. Reset nets remain isolated; do not short PG,
RTN or the permission chain to invent reset behaviour.
[source](https://www.ckswitches.com/media/1479/kmr2.pdf)

## Depth, assembly and outstanding checks

The carrier bounding depth remains **30 mm**, rear Z32 = **30.4 mm behind panel**.
This is not finished module depth: cable budget Z34..50 is provisional. The four
bays leave a continuous 11.5 mm rear spine but consume layout area. The full
power circuit remains unplaced; converter fit, thermal spreading and routing on
this shape are unproven. The middle's 2.1 mm USB-side spine is also unqualified.

Trial sequence: measure hardware/tool → fit 10 mm supports → assemble and solder
headers without forced preload → mate carrier and braces → demonstrate removing,
starting and tightening **each** M3 nut through its side bay with carrier retained
→ verify USB/LED/reset and rail/adjacent-panel fit. Test with power disconnected.
Do not declare completion of physical fit from these drawings or unit tests.

Research basis remains the separable perpendicular-board header construction in
Delptronics MCS and distributed panel supports in Powerline USB-C; neither proves
this narrower 2HP assembly. No third-party artwork or electrical circuit copied.
[source](https://delptronics.com/module-construction-set.php)
[source](https://github.com/Andreas-Dorfner/Powerline-USB-C)
