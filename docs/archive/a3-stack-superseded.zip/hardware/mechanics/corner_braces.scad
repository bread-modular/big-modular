// Big Modular A3: two open-sided corner-brace FIT PROTOTYPES, mm.
// Panel supports are M3 10+6 or 10mm spacers. The two small transverse
// carrier bolts remain M2x8 (not M2 standoffs). NOT strength-qualified.
// Global assembly datums are literal to enable comparison with geometry JSON.
// Print one of each, with flange on bed. No STL/print validation performed.
$fn = 48;
foot_x = [0.5, 9.3];
web_x = [3.17, 8.97];
base_z = 13.2;
seat = 1.0;               // plus <=0.5 washer: 6-1.6-1-.5-2.4 = .5mm stud exit
back_z = 30.5;
side_z = 25.2;
front_x = 4.9;
nut_af = 4.2;            // M2 captive nut <=4.0 AF
nut_depth = 1.8;

module brace(lower=false) {
    fy = lower ? [74.5,92.5] : [37,54];
    wy = lower ? [86.5,92.5] : [37,43];
    support_y = lower ? 78.5 : 50;
    side_y = lower ? 89.5 : 40;
    difference() {
        union() {
            translate([foot_x[0],fy[0],base_z])
                cube([foot_x[1]-foot_x[0],fy[1]-fy[0],seat]);
            translate([web_x[0],wy[0],base_z+seat])
                cube([web_x[1]-web_x[0],wy[1]-wy[0],back_z-base_z-seat]);
        }
        // M3 shank; nut and wrench sit ABOVE this foot, in an open side bay.
        translate([front_x,support_y,base_z-0.1]) cylinder(h=seat+0.2,d=3.2);
        // M2 carrier bolt along X. Nut enters from right; driver from left.
        translate([web_x[0]-0.1,side_y,side_z]) rotate([0,90,0])
            cylinder(h=web_x[1]-web_x[0]+0.2,d=2.2);
        translate([web_x[1]-nut_depth,side_y,side_z]) rotate([0,90,0]) rotate([0,0,30])
            cylinder(h=nut_depth+0.1,d=nut_af/cos(30),$fn=6);
    }
}
// Separate print-bed coordinates; assembly locations above are not changed.
translate([-foot_x[0],-37,-base_z]) brace(false);
translate([13-foot_x[0],-74.5,-base_z]) brace(true);
