# A3 M3 stack validation — placement only, NOT fabrication approval

## Delivered changes

- Simple round Ø3.2 left-corner rail holes, X2.42 / Y3 and Y125.5. This is one
  5.08 mm pitch left of X7.50, not A2's off-grid centred slot. Common fixed-strip
  phase is supported; sliding nuts are no longer required by the design.
- Four front/middle Ø3.2 support holes at X4.9, Y17.5 / 50 / 78.5 / 111.
- M3 10 mm body supports, with 6 mm rearward studs or 10 mm spacer alternatives.
  Middle moved from Z7.6..9.2 to **Z11.6..13.2**. Both carrier socket rows moved
  back 4 mm; J3/J5 shifted together from Y27 to Y26.
- **Four side-access bays** keep the M3 nuts and spanner approach clear with the
  carrier's right-angle sockets soldered AND plugged into the middle headers.
  A 5.5AF open spanner with head ≤12 mm wide / ≤3 mm thick is the design envelope.
  Service is **out of rack**, from +X; no rear socket-driver claim is made.
- Open-sided brace feet are 1 mm at the M3 clamp seats, permitting the specified
  6 mm studs to engage full plain nuts with 0.5 mm washers. **Two small transverse
  M2×8 brace bolts remain**; these are not the panel standoffs.
- USB native footprint/datum, LED/reset XY positions and openings unchanged.
  Carrier still 30 mm depth envelope, rear Z32 = **30.4 mm behind panel rear**.
  Full populated/cabled module depth and converter fit remain unverified.

Current drawings: [assembly](../docs/assembly.pdf), [M3 access](../docs/m3-access.pdf).
Full dimensions/options/limits: [mechanics](../docs/mechanics.md).

## Executed checks

| Check | Result / scope |
|---|---|
| Local unittest suite | **27 passed**: 18 existing updated checks + 9 new M3 checks; full current log in `stack-tests.txt` |
| Native geometry | 3 board outlines; 16 NPTH locations/drills; 7 numbered mating pin axes; actual edge connectivity including all four access bays |
| M3 access | All four swept tool boxes clear verified carrier solids, soldered/mated connector envelopes and offset brace uprights |
| Thread options | Full nut + 1.5 mm stud at ends / 0.5 mm at brace positions; plain-spacer M3×18 exit 1.9 / 0.9 mm; F/F opposing-tip gaps 1.7 / 0.7 mm |
| Obstruction negatives | Solid carrier front, narrow bay that clears the nut but blocks its tool, header in service lane, oversized tool, thicker seat/nut are all rejected |
| Deterministic generation | Three PCB candidates reproduce delivered boards byte-for-byte; SVGs and geometry JSON reproduce exactly; existing output paths rejected |
| Preservation | Original circuit files/rules/BOM/pin audit and J1 native AST still match `stack-source-preservation.json` |
| Circuit regression | 260 connected pins, 65 independent spot checks, 20 wire/hierarchy paths + 1 named continuation, 57 local wire paths, 28 gate cases pass |
| Routing guard | Zero tracks, vias, zones or copper graphics on all three boards |
| 2D visual review | Actual native PCB plots plus dimensioned assembly and tool-access SVGs inspected |
| Print source | Literal parameter/handedness regression only; **OpenSCAD unavailable**, so no evaluated solid, mesh, print or strength test |
| Whitespace | `git diff --check` clean |

Thread results are nominal arithmetic, not measured tolerance stacks. The
verification includes a conservative tool bounding box, not a measured commercial
wrench model or a tolerance/torque simulation. Body OD/AF and usable female thread
depth are design acceptance limits, not claims about the user's unknown parts.

## Native ERC / DRC / parity (all findings retained)

Fresh shared-tool evidence: [`stack-a3-native/summary.json`](stack-a3-native/summary.json)
with original command/stdout/stderr records. The older `stack-native/` folder is
A2 historical evidence, **not** the current PCB check.

| Source / report | Result |
|---|---|
| Per-board carrier `carrier-drc.json` | **4 existing USB hole_clearance errors**, 8 intentional unrouted items |
| Per-board middle `middle-drc.json` | **0 violations**, 9 intentional unrouted items |
| Per-board panel `panel-drc.json` | **0 violations**, 0 unrouted items |
| Private carrier DRC, refill + schematic parity | Same 4 violations + 8 opens; **113 native parity findings** retained |
| Private ERC | **68 pre-existing footprint-library configuration warnings**, no new circuit changes |
| Separate native ref/pin/net parity | 86 missing refs, 6 extra refs, 255 missing pins, 17 net-name mismatches, 6 extra connected pads, 7 pads without nets — retained, NOT corrected by routing or schematic synchronization |
| Shared check status | `findings`, exit 1, `source_unchanged: true`, `order_ready: false`, no infrastructure errors |

The power circuit is still unplaced. LED/reset/connector additions are PCB-only
reservations, absent from the 88-part circuit schematic/root BOM. The middle and
panel have no companion schematic and were not fraudulently paired with the
carrier circuit to manufacture a clean result. No rules or findings were waived.

The common PCB edit/inspect tool was attempted first and still fails closed on
its unsupported 3D-model dependency. The narrow existing native stack generator
therefore produced **new review candidates**, then the checked files were copied
into `hardware/`. The original J1 object was not rebuilt or substituted.

## Physical acceptance still required

- Confirm actual 10+6 standoff dimensions, ≤6 AF / ≤7 round body, ≥5 mm usable
  female depth, plain M3 nut ≤5.5 AF / ≤2.4 high, washer ≤7 OD / 0.5 thick.
- Trial the actual open spanner, including starting/removing nuts and re-indexing,
  on **all four** locations with the soldered carrier mated. The tool extends
  beyond the module width, so access between installed neighbours is not promised.
- Test the **1 mm brace seats**, printed layer orientation/creep/temperature,
  thin middle spine and PCB bearing under USB insertion/cable torque. SCAD is
  a fit prototype, not a qualified structural design or validated print.
- Check actual rails and neighbour clearance: Ø3.2 corner holes leave 0.82 mm FR4
  side web. A 6 mm head overhangs the panel by 0.58; ≤4.6 diameter avoids nominal
  overhang. No countersink or universal rail-family fit is claimed.
- Select exact header pair, verify engagement/trimmed tails/solder envelope, USB
  shell/plug and cable strain relief. Preserve tool bays during future placement.
- Recheck recessed LED visibility and optional light pipe after the 4 mm setback.
  Reset candidate tip is now nominal Z9.7; no actuator or reset circuit selected.
- Complete converter placement/thermal/electrical protection reviews before
  routing. More edge cutbacks reduce usable placement area; 30 mm depth alone
  does not prove full converter fit.

No routing, Gerbers, manufacturing upload, ordering, commit or Bread Modular
changes were performed. All work remains in Big Modular workspace 010.
