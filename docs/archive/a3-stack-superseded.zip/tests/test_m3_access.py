"""Positive AND negative A3 fit checks; no hardware-fit claim from unit tests."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tools'))
from stack_geometry import geometry, carrier_outline
from m3_fit import verify_access


def rows():
    return [[26,28.54,31.08,33.62],[96,98.54,101.08]]


class M3AccessTests(unittest.TestCase):
    def test_corner_holes_are_round_and_one_grid_pitch_left(self):
        g=geometry()
        self.assertEqual(g['rail_holes_mm'],[[2.42,3,3.2],[2.42,125.5,3.2]])
        self.assertAlmostEqual(7.5-g['rail_holes_mm'][0][0],5.08)
        self.assertNotIn('rail_slots_mm',g)

    def test_all_supports_clear_after_soldering_and_mating(self):
        r=verify_access(geometry(),carrier_outline(),rows())
        self.assertEqual(len(r['positions']),4)
        self.assertTrue(all(p['collision_free_nominal'] for p in r['positions']))
        self.assertIn('soldered AND mated',r['service_condition'])
        self.assertIn('OUT OF RACK',r['service_condition'])
        self.assertEqual([p['stud_exposure_mm'] for p in r['positions']],[1.5,.5,.5,1.5])
        self.assertEqual([p['plain_spacer_exposure_mm'] for p in r['positions']],[1.9,.9,.9,1.9])
        self.assertEqual([p['female_female_tip_gap_mm'] for p in r['positions']],[1.7,.7,.7,1.7])

    def test_solid_front_edge_is_rejected(self):
        unrelieved=[(14,15),(57.5,15),(57.5,2),(71,2),(71,15),(114.5,15),(114.5,32),(14,32)]
        with self.assertRaisesRegex(AssertionError,'nut/washer/bolt collision'):
            verify_access(geometry(),unrelieved,rows())

    def test_wrench_obstruction_is_rejected_even_when_nut_fits(self):
        narrowed=[(45.5 if y==43.5 else y,z) for y,z in carrier_outline()]
        with self.assertRaisesRegex(AssertionError,'side spanner access blocked'):
            verify_access(geometry(),narrowed,rows())

    def test_header_in_service_lane_is_rejected(self):
        moved=rows();moved[0]=[48,50.54,53.08,55.62]
        with self.assertRaises(AssertionError):
            verify_access(geometry(),carrier_outline(),moved)

    def test_thicker_brace_or_nut_cannot_silently_consume_stud(self):
        for key in ['brace_seat_thickness_mm','nut_height_max_mm']:
            g=geometry();g['spacers'][key]+=1
            with self.assertRaises(AssertionError):
                verify_access(g,carrier_outline(),rows())

    def test_larger_tool_does_not_get_the_small_tool_result(self):
        g=geometry();g['nut_access']['tool_head_Y_width_max_mm']=18
        with self.assertRaisesRegex(AssertionError,'side spanner access blocked'):
            verify_access(g,carrier_outline(),rows())

    def test_drawing_regeneration_matches_current_contract(self):
        with tempfile.TemporaryDirectory(prefix='big modular M3 drawing ') as tmp:
            out=Path(tmp)/'drawings'
            cmd=[sys.executable,'-B',str(ROOT/'tools/build_mechanics.py'),'--output',str(out)]
            r=subprocess.run(cmd,capture_output=True,text=True,timeout=60)
            self.assertEqual(r.returncode,0,r.stdout+r.stderr)
            for name in ['assembly.svg','m3-access.svg','assembly-geometry.json']:
                self.assertEqual((out/name).read_bytes(),(ROOT/'docs'/name).read_bytes(),name)
            self.assertEqual(json.loads((out/'assembly-geometry.json').read_text()),geometry())
            self.assertTrue((out/'m3-access.pdf').read_bytes().startswith(b'%PDF-'))

    def test_print_source_keeps_thin_seat_and_both_open_braces(self):
        # Text-contract check only: OpenSCAD is unavailable; this is NOT a solid/mesh test.
        s=(ROOT/'hardware/mechanics/corner_braces.scad').read_text()
        for literal in ['seat = 1.0','base_z = 13.2','side_z = 25.2','back_z = 30.5',
                        'front_x = 4.9','[74.5,92.5] : [37,54]',
                        '[86.5,92.5] : [37,43]','78.5 : 50','89.5 : 40','d=3.2']:
            self.assertIn(literal,s)


if __name__=='__main__':unittest.main()
