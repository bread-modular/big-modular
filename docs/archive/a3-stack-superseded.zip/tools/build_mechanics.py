#!/usr/bin/env python3
"""Render the original A3 dimensioned assembly drawing to a NEW output directory."""
from pathlib import Path
from html import escape
import argparse
import json
import subprocess
from stack_geometry import geometry, carrier_outline, middle_outline


def build(output):
    output.mkdir(parents=True, exist_ok=False)
    g = geometry()
    (output/'assembly-geometry.json').write_text(json.dumps(g, indent=2)+'\n')
    a = ['<svg xmlns="http://www.w3.org/2000/svg" width="420mm" height="297mm" viewBox="0 0 420 297">',
         '<defs><marker id="arrow" markerWidth="5" markerHeight="5" refX="2.5" refY="2.5" orient="auto-start-reverse"><path d="M0,0 L5,2.5 L0,5" fill="#4c6171"/></marker></defs>',
         '<style>text{font-family:DejaVu Sans,sans-serif;fill:#19334b}.dim{stroke:#4c6171;stroke-width:.2;marker-start:url(#arrow);marker-end:url(#arrow)}.axis{stroke:#bc593e;stroke-width:.25;stroke-dasharray:2 1}</style>',
         '<rect x="5" y="5" width="410" height="287" fill="#fff" stroke="#213f58" stroke-width=".4"/>']
    def text(x,y,s,size=2.5,color='#19334b'):
        a.append(f'<text x="{x}" y="{y}" font-size="{size}" style="fill:{color}">{escape(s)}</text>')
    def lines(x,y,ss,size=2.5,step=4):
        for i,s in enumerate(ss):text(x,y+i*step,s,size)
    def rect(x,y,w,h,fill='none',dash=False,rx=0):
        a.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}" stroke="#375775" stroke-width=".25"'+(' stroke-dasharray="2 1"' if dash else '')+'/>')
    def line(x1,y1,x2,y2,cl=''):
        a.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#375775" stroke-width=".25" class="{cl}"/>')
    def circle(x,y,r,fill='white'):
        a.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="#375775" stroke-width=".25"/>')
    def poly(points,fill):
        a.append('<polygon points="'+' '.join(f'{x},{y}' for x,y in points)+f'" fill="{fill}" stroke="#375775" stroke-width=".3"/>')
    def dim(x1,y1,x2,y2,label,tx,ty):line(x1,y1,x2,y2,'dim');text(tx,ty,label,2.4)

    text(11,15,'BIG MODULAR  |  A3 M3 / 10mm SHALLOW STACK',5)
    text(11,22,'PLACEMENT / FIT PROPOSAL ONLY — NO ROUTING — NOT FOR FABRICATION',3,'#ab352c')
    text(11,28,'mm; panel origin upper-left; X right, Y down, Z into case. All part envelopes nominal; exact mating hardware and actuator unselected.',2.6)
    s=1.14; fy=43
    # Front panel.
    fx=24
    text(11,36,'FRONT / TOP PANEL',3.2)
    rect(fx,fy,9.8*s,128.5*s,'#f1dfb6')
    for x,y,d in g['rail_holes_mm']:circle(fx+x*s,fy+y*s,d*s/2)
    for x,y,d in g['panel_spacer_holes_mm']:circle(fx+x*s,fy+y*s,d*s/2)
    x,y,w,h,r=g['aperture_XYWHR_mm'];rect(fx+x*s,fy+y*s,w*s,h*s,'white',rx=r*s)
    for key,fill in [('led_XY_diameter_mm','#99da8a'),('reset_XY_diameter_mm','white')]:
        x,y,d=g[key];circle(fx+x*s,fy+y*s,d*s/2,fill)
    for y,label in [(17.5,'M3 / Y17.5'),(38,'PWR / Y38'),(50,'M3 / Y50'),(64.25,'USB / Y64.25'),(78.5,'M3 / Y78.5'),(91,'RESET / Y91'),(111,'M3 / Y111')]:
        line(fx+9.8*s,fy+y*s,43,fy+y*s);text(44,fy+y*s+1,label,2.3)
    dim(fx,fy-3,fx+9.8*s,fy-3,'9.80',fx,fy-5)
    dim(18,fy,18,fy+128.5*s,'128.50',6.5,119)
    lines(42,51,['ROUND dia3.2','X2.42; Y3/125.5','FIXED-GRID PHASE'],2.2,3.6)
    lines(13,195,['USB opening 4.2 x 9.8 R0.6','LED window dia2.4; reset dia3.2','No toggle / printed cap selected'],2.25,3.8)

    # Middle/front-facing PCB view (projected through panel).
    mx=103
    text(92,36,'MIDDLE / CONTROL PCB',3.2)
    poly([(mx+x*s,fy+y*s) for x,y in middle_outline()],'#d5eee4')
    for x,y,d in g['panel_spacer_holes_mm']:circle(mx+x*s,fy+y*s,d*s/2)
    for pair in g['headers']['pairs']:
        for i in range(pair['pins']):
            x=g['headers']['contact_X_mm']; y=pair['Y1_mm']+i*2.54
            rect(mx+(x-1.27)*s,fy+(y-1.27)*s,2.54*s,2.54*s,'#687c8c')
    rect(mx+4.1*s,fy+37.6*s,1.6*s,.8*s,'#75d073')
    rect(mx+4.1*s,fy+41.6*s,1.6*s,.8*s,'#48566b')
    rect(mx+2.8*s,fy+89.6*s,4.2*s,2.8*s,'#667a88')
    circle(mx+4.9*s,fy+91*s,.8*s,'#ddd')
    for y,ss in [(26,['J5: 1x4 on BACK','straight male']), (38,['D10 0603 on FRONT','R32 current limit']), (62,['USB + carrier tongue','pass through notch','2.1mm spine at right']), (91,['SW1 KMR2 candidate','NO, two isolated nets']), (100,['J6: 1x3 on BACK'])]:
        line(mx+9.3*s,fy+y*s,120,fy+y*s);lines(121,fy+y*s,ss,2.2,3.6)
    lines(94,195,['8.8 x 100.5 x 1.6; Y14..114.5','Front Z11.6; rear Z13.2','Four 10mm M3 supports; holes X4.9'],2.25,3.8)

    # Side projection. X hidden; Z horizontal, Y vertical.
    bx=179
    text(176,36,'SIDE / INTO CASE +Z',3.2)
    rect(bx,fy,1.6*s,128.5*s,'#f1dfb6')
    # Middle board as two bars in this section; notch clears USB tongue.
    for lo,hi in [(14,56.5),(72,114.5)]:rect(bx+11.6*s,fy+lo*s,1.6*s,(hi-lo)*s,'#d5eee4')
    poly([(bx+z*s,fy+y*s) for y,z in carrier_outline()],'#d6e3f1')
    for y,z in g['carrier_holes_YZ_mm']:circle(bx+z*s,fy+y*s,1.1*s)
    for _,y,_ in g['panel_spacer_holes_mm']:rect(bx+1.6*s,fy+(y-3)*s,10*s,6*s,'#bdc7cf')
    for lo,hi in g['braces']['foot_Y_mm']:rect(bx+13.2*s,fy+lo*s,1*s,(hi-lo)*s,'#e8b396')
    for lo,hi in g['braces']['web_Y_mm']:rect(bx+14.2*s,fy+lo*s,16.3*s,(hi-lo)*s,'#e8b396',True)
    for (_,yc,_),seat in zip(g['panel_spacer_holes_mm'],g['nut_access']['nut_seat_Z_mm']):
        rect(bx+seat*s,fy+(yc-6)*s,3*s,12*s,'#d3e8f5',True)
        rect(bx+seat*s,fy+(yc-2.75)*s,2.4*s,5.5*s,'#c4a578')
    for pair in g['headers']['pairs']:
        y=pair['Y1_mm'];h=pair['pins']*2.54
        rect(bx+13.2*s,fy+(y-1.27)*s,2.54*s,h*s,'#abb9c0')
        rect(bx+15.74*s,fy+(y-1.27)*s,8.51*s,h*s,'#566f80')
    rect(bx+.8*s,fy+59.78*s,7.6*s,8.94*s,'#d4d5d7')
    line(bx-7,fy+64.25*s,bx+10*s,fy+64.25*s,'axis')
    rect(bx+34*s,fy+40*s,16*s,35*s,'none',True)
    lines(bx+35*s,fy+48*s,['CABLE','budget','only'],2.2,4)
    dim(bx+2*s,fy+133*s,bx+32*s,fy+133*s,'30.0 PCB envelope',bx+5,fy+138*s)
    lines(176,207,['Rear edge Z32 = 30.4 behind panel','Cable budget to Z50 is UNQUALIFIED'],2.25,3.8)

    # Enlarged connector cross section XZ. X right, Z down.
    text(263,37,'HEADER SECTION / TOP VIEW',3.2)
    k=3.6;tx=268;ty=43
    rect(tx,ty,9.8*k,1.6*k,'#f1dfb6')
    rect(tx+.5*k,ty+11.6*k,8.8*k,1.6*k,'#d5eee4')
    rect(tx+1.57*k,ty+15*k,1.6*k,17*k,'#d6e3f1')
    rect(tx+3.17*k,ty+15.74*k,2.54*k,8.51*k,'#566f80')
    rect(tx+3.17*k,ty+13.2*k,2.54*k,2.54*k,'#abb9c0')
    rect(tx+(4.44-.32)*k,ty+15.74*k,.64*k,6*k,'#d7ad61')
    line(tx+4.44*k,ty+6*k,tx+4.44*k,ty+27*k,'axis')
    line(tx+.47*k,ty+25.77*k,tx+4.44*k,ty+25.77*k)
    lines(310,48,['Panel Z0..1.6','10mm clear gap','Middle Z11.6..13.2','Male pins point +Z','Socket opens -Z','Socket contact X4.44','1.27 above carrier F.Cu','Carrier X1.57..3.17','Pad row Z25.77','Mouth Z15.74','6mm nominal engagement','Trim tails <=2.7 + solder0.2','Exact pair still UNSELECTED'],2.35,5)
    lines(264,166,[
        'M3 NUT ACCESS: four side-open bays (blue in side view).',
        '5.5AF spanner, head <=12 wide and <=3 thick; from +X.',
        'Works with soldered + plugged-in carrier, OUT OF RACK.',
        '10+6 standoff: M3x6 front; washer + M3 nut at rear.',
        '10mm plain spacer: fully threaded M3x18 + rear nut.',
        'Thin 1mm brace seat + 0.5 washer: stud exits nut 0.5.',
        'Two transverse M2x8 brace bolts retained, not standoffs.',
        'See m3-access.svg for enlarged tool / fastener sections.'
    ],2.4,4.8)


    line(10,218,410,218)
    lines(11,226,[
        'ASSEMBLY: four M3 supports give a 10mm gap; nuts remain side-accessible with the carrier soldered and mated. Service outside the rack.',
        'LOAD PATH: USB stakes -> carrier -> two braces -> middle/spacers -> panel. Do not use the 2.54mm contacts as the only structural support.',
        'CIRCUIT UNCHANGED: UI power/LED/reset/header pads are isolated placement reservations, NOT in the circuit schematic. Reset function is undecided.',
        'RESET: only a dia3.2 access hole and front-facing tactile footprint. A future captive printed plunger needs a hard stop and no idle preload.',
        'RAIL HOLES: left-corner round holes X2.42 = 7.50 - 5.08. Same common fixed-strip grid phase; sliding nuts are no longer required.',
        'FIT GATES: actual M3 body/nut/tool dimensions, 1mm brace seat strength, screw-head neighbour clearance, USB/header fit and cable bend.',
        'DEPTH: still 30mm carrier envelope / rear Z32 despite the 10mm supports. Full converter placement, thermal margins and the provisional Z50 cable envelope remain open.',
        'Precedents: Delptronics MCS perpendicular header boards; Powerline USB-C two-point spacer support. See mechanics.md for links and differences.'
    ],2.55,7.4)
    a.append('</svg>')
    (output/'assembly.svg').write_text('\n'.join(a)+'\n')
    subprocess.run(['rsvg-convert','-f','pdf','-o',str(output/'assembly.pdf'),str(output/'assembly.svg')],check=True)
    access_drawing(output, g)
    print('Created A3 assembly + M3 access drawings and geometry:',output)


def access_drawing(output, g):
    a = ['<svg xmlns="http://www.w3.org/2000/svg" width="420mm" height="297mm" viewBox="0 0 420 297">',
         '<style>text{font-family:DejaVu Sans,sans-serif;fill:#19334b}</style>',
         '<rect x="5" y="5" width="410" height="287" fill="white" stroke="#375775" stroke-width=".4"/>']
    def text(x,y,t,size=2.7): a.append(f'<text x="{x}" y="{y}" font-size="{size}">{escape(t)}</text>')
    def rect(x,y,w,h,c,dash=False):
        a.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{c}" stroke="#375775" stroke-width=".25"'+(' stroke-dasharray="2 1"' if dash else '')+'/>')
    def line(x1,y1,x2,y2):a.append(f'<path d="M{x1},{y1} L{x2},{y2}" stroke="#375775" stroke-width=".25"/>')
    text(11,15,'A3  |  M3 FASTENERS + POST-SOLDER NUT ACCESS',5)
    text(11,23,'Nominal fit proposal. Module OUT OF RACK. Carrier remains soldered and plugged in. mm.',3)
    text(14,35,'SECTION XZ AT UPPER BRACE / Y50',3.2)
    k=4.5; x0=28; z0=44
    def section(x,z,w,h,c,dash=False):rect(x0+x*k,z0+z*k,w*k,h*k,c,dash)
    section(0,0,9.8,1.6,'#f1dfb6')
    section(1.9,1.6,6,10,'#bdc7cf')
    section(.5,11.6,8.8,1.6,'#d5eee4')
    section(.5,13.2,8.8,1,'#e8b396')
    section(1.4,14.2,7,.5,'#777')
    section(2.15,14.7,5.5,2.4,'#c4a578')
    section(3.4,11.6,3,6,'#97a4ae')
    section(1.57,20.5,1.6,11.5,'#d6e3f1')
    section(-1.1,14.7,31.1,3,'none',True)
    line(x0+28*k,z0+16.2*k,x0+9*k,z0+16.2*k)
    text(97,102,'<-- 5.5 AF open-ended spanner',2.7)
    text(97,126,'Side entry +X; head <=12 wide, <=3 thick',2.6)
    for y,t in [(51,'Panel 0..1.6'),(62,'10mm body, not 10mm overall'),(73,'6mm male stud points rearward'),(84,'Middle 11.6..13.2'),
                (132,'Brace foot 1.0 + washer 0.5'),(143,'M3 nut 2.4; full nut + 0.5mm stud exit'),
                (160,'Carrier recessed to Z20.5 at supports'),(171,'Nut / wrench fit IN FRONT of carrier'),(182,'This is NOT rear nut-driver access')]:text(97,y,t,2.6)
    text(15,204,'Four front-to-middle supports: M3 clearance holes dia3.2',3)
    for i,t in enumerate(['M/F: M3x6 front screw; 10+6 standoff; washer + M3 rear nut.',
                          'Plain tube: 10mm spacer + fully threaded M3x18 through bolt.',
                          'F/F: M3x6 front; M3x6 ends / M3x8 brace positions at rear.',
                          'Body <=6mm hex AF or <=7mm round; nut <=5.5AF x 2.4 high.',
                          'Washer <=7 OD x 0.5. Do not substitute thicker / nyloc nuts.',
                          'Two small M2x8 transverse brace bolts retained; no M2 standoffs.']):text(15,214+i*5.2,t,2.6)
    # XY cross-section at Z15.9: main-board material and brace uprights are obstacles.
    text(237,35,'XY SECTION Z15.9 / TOOL LANES',3.2)
    x1=257;y1=42;t=1.15
    rect(x1,y1,9.8*t,128.5*t,'none',True)
    for lo,hi in [(24,43.5),(56.5,72),(85,104.5)]:rect(x1+1.57*t,y1+lo*t,1.6*t,(hi-lo)*t,'#d6e3f1')
    for lo,hi in g['braces']['web_Y_mm']:rect(x1+3.17*t,y1+lo*t,5.8*t,(hi-lo)*t,'#e8b396')
    for pair in g['headers']['pairs']:
        rect(x1+3.17*t,y1+(pair['Y1_mm']-1.27)*t,2.54*t,pair['pins']*2.54*t,'#566f80')
    for _,yc,_ in g['panel_spacer_holes_mm']:
        rect(x1-1.1*t,y1+(yc-6)*t,31.1*t,12*t,'none',True)
        rect(x1+2.15*t,y1+(yc-2.75)*t,5.5*t,5.5*t,'#c4a578')
        text(299,y1+yc*t+1,f'<-- side lane / Y{yc:g}',2.6)
    text(237,196,'Dashed boxes: tool envelope including handle approach.',2.6)
    text(237,205,'Blue: actual carrier section. Orange: brace uprights.',2.6)
    text(237,214,'At 6mm stud length, nut exposure after 0.5 washer:',2.6)
    text(245,224,'Y17.5 / Y111 ends: 1.5mm',2.8)
    text(245,234,'Y50 / Y78.5 with 1mm brace foot: 0.5mm',2.8)
    text(237,245,'Actual spanner silhouette, tolerances and thread runout',2.6)
    text(237,251,'need a physical trial; keep these access lanes copper-free.',2.6)
    line(10,261,410,261)
    text(11,270,'Keep nuts reachable after soldering; do NOT solve access by relying on a pre-solder assembly order.',2.9)
    text(11,278,'Thin brace seat / FR4 strength and header engagement are unqualified. No routing, thermal proof or fabrication approval.',2.7)
    a.append('</svg>')
    (output/'m3-access.svg').write_text('\n'.join(a)+'\n')
    subprocess.run(['rsvg-convert','-f','pdf','-o',str(output/'m3-access.pdf'),str(output/'m3-access.svg')],check=True)


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True,help='NEW output directory')
    build(parser.parse_args().output)
