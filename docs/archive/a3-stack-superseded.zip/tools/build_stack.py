#!/usr/bin/env python3
"""Build a NEW unrouted A3 mechanical/placement candidate, never overwrite hardware.

Common-tool pcb inspect rejects the retained USB model dependency; its edit subset
also cannot change these NPTHs/arcs or introduce schematic-less UI reservations.
This deliberately narrow native generator complements (does not replace) the
common check tool. The original J1 object and entire circuit hierarchy are kept.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import shutil
import uuid
import pcbnew as pcb
from stack_geometry import geometry, carrier_xy, panel_xy, middle_xy, carrier_outline, middle_outline

ROOT = Path(__file__).resolve().parents[1]
G = geometry()
MM = pcb.FromMM


def vec(x, y):
    return pcb.VECTOR2I(MM(x), MM(y))


def line(board, start, end, layer=pcb.Edge_Cuts):
    obj = pcb.PCB_SHAPE()
    obj.SetShape(pcb.SHAPE_T_SEGMENT)
    obj.SetStart(vec(*start)); obj.SetEnd(vec(*end)); obj.SetLayer(layer)
    obj.SetWidth(MM(.05 if layer == pcb.Edge_Cuts else .15)); board.Add(obj)


def polygon(board, points, layer=pcb.Edge_Cuts):
    for a, b in zip(points, points[1:] + points[:1]):
        line(board, a, b, layer)


def rounded_aperture(board, x, y, w, h, r):
    k = r / math.sqrt(2)
    segments = [((x+r,y),(x+w-r,y)), ((x+w,y+r),(x+w,y+h-r)),
                ((x+w-r,y+h),(x+r,y+h)), ((x,y+h-r),(x,y+r))]
    arcs = [((x+w-r,y),(x+w-r+k,y+r-k),(x+w,y+r)),
            ((x+w,y+h-r),(x+w-r+k,y+h-r+k),(x+w-r,y+h)),
            ((x+r,y+h),(x+r-k,y+h-r+k),(x,y+h-r)),
            ((x,y+r),(x+r-k,y+r-k),(x+r,y))]
    for a, b in segments: line(board, a, b)
    for a, m, b in arcs:
        obj = pcb.PCB_SHAPE(); obj.SetShape(pcb.SHAPE_T_ARC)
        obj.SetArcGeometry(vec(*a), vec(*m), vec(*b)); obj.SetLayer(pcb.Edge_Cuts)
        obj.SetWidth(MM(.05)); board.Add(obj)


def text(board, value, x, y, size=.8, layer=pcb.Dwgs_User):
    obj = pcb.PCB_TEXT(board); obj.SetText(value); obj.SetPosition(vec(x, y))
    obj.SetTextSize(vec(size, size)); obj.SetTextThickness(MM(.12)); obj.SetLayer(layer)
    board.Add(obj)


def hole(board, ref, at, diameter, dy=None, contact_radius=2.1):
    dy = diameter if dy is None else dy
    fp = pcb.FOOTPRINT(board); fp.SetReference(ref); fp.SetValue('MECHANICAL_NPTH')
    fp.SetPosition(vec(*at)); fp.Reference().SetVisible(False); fp.Value().SetVisible(False)
    pad = pcb.PAD(fp); pad.SetAttribute(pcb.PAD_ATTRIB_NPTH)
    pad.SetShape(pcb.PAD_SHAPE_CIRCLE if diameter == dy else pcb.PAD_SHAPE_OVAL)
    pad.SetSize(vec(diameter, dy)); pad.SetDrillSize(vec(diameter, dy))
    if diameter != dy: pad.SetDrillShape(pcb.PAD_DRILL_SHAPE_OBLONG)
    pad.SetLayerSet(pcb.LSET.AllCuMask()); pad.SetPosition(vec(*at))
    fp.Add(pad); board.Add(fp)
    # Drawing-only screw/washer contact reservation: deliberately NOT copper zones.
    if contact_radius:
        obj = pcb.PCB_SHAPE(); obj.SetShape(pcb.SHAPE_T_CIRCLE)
        obj.SetCenter(vec(*at)); obj.SetEnd(vec(at[0]+contact_radius, at[1]))
        obj.SetLayer(pcb.Dwgs_User); obj.SetWidth(MM(.1)); board.Add(obj)


def board():
    b = pcb.BOARD(); b.SetCopperLayerCount(2)
    b.GetDesignSettings().SetBoardThickness(MM(1.6))
    return b


def placed(b, hw, lib, name, ref, value, at, nets, rotation=0, back=False):
    target = hw/'BigModular.pretty'/f'{name}.kicad_mod'
    if not target.exists():
        shutil.copyfile(Path('/usr/share/kicad/footprints')/(lib+'.pretty')/(name+'.kicad_mod'), target)
    fp = pcb.FootprintLoad(str(target.parent), name)
    fp.SetFPID(pcb.LIB_ID('BigModular', name)); fp.SetReference(ref); fp.SetValue(value)
    fp.SetPosition(vec(*at))
    b.Add(fp)  # Native Flip needs a parent board/layer stack.
    if back: fp.Flip(fp.GetPosition(), pcb.FLIP_DIRECTION_LEFT_RIGHT)
    fp.SetOrientationDegrees(rotation)
    fp.Reference().SetVisible(False); fp.Value().SetVisible(False)
    fp.SetLocked(True)
    for pad in fp.Pads():
        name = nets.get(pad.GetNumber(), '')
        if name:
            net = b.FindNet(name)
            if not net:
                net = pcb.NETINFO_ITEM(b, name); b.Add(net)
            pad.SetNet(net)
    return fp


def stable_ids(b, name):
    # Deterministic generated IDs; preserve every existing J1 child/UUID verbatim.
    ns = uuid.uuid5(uuid.NAMESPACE_URL, 'big-modular/A3/'+name)
    def setid(obj, key): obj.SetUuid(pcb.KIID(str(uuid.uuid5(ns, key))))
    for i, d in enumerate(b.GetDrawings()): setid(d, f'drawing:{i}')
    for fp in b.GetFootprints():
        ref = fp.GetReference()
        if ref == 'J1': continue
        setid(fp, ref)
        for i, obj in enumerate(list(fp.Pads())+list(fp.GraphicalItems())+list(fp.GetFields())):
            setid(obj, f'{ref}:child:{i}')


def build(output):
    output = output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    hw = output/'hardware'; hw.mkdir()
    pretty = hw/'BigModular.pretty'
    shutil.copytree(ROOT/'hardware/BigModular.pretty', pretty)
    for name in ['fp-lib-table', 'big_modular.kicad_pro', 'front_panel.kicad_pro']:
        shutil.copyfile(ROOT/'hardware'/name, hw/name)
    # Preserve board setup/net definitions and J1's native object exactly.
    b = pcb.LoadBoard(str(ROOT/'hardware/big_modular.kicad_pcb'))
    assert not list(b.GetTracks()) and not list(b.Zones()), 'Refuse to erase routed design'
    refs = {f.GetReference() for f in b.GetFootprints()}
    assert refs <= {'J1','J3','J4','H1','H2','H3','H4'} and 'J1' in refs, 'Unexpected placed circuitry'
    # KiCad's Python Remove wrapper corrupts ownership on this engine; use the
    # same native-detach/retained-lifetime pattern as the shared edit worker.
    retired = list(b.GetDrawings()) + [f for f in b.GetFootprints() if f.GetReference() != 'J1']
    for item in retired:
        b.RemoveNative(item)
        item.thisown = False
    polygon(b, [carrier_xy(*p) for p in carrier_outline()])
    for i, point in enumerate(G['carrier_holes_YZ_mm'], 1): hole(b, f'H{i}', carrier_xy(*point), 2.2)
    for pair in G['headers']['pairs']:
        placed(b, hw, 'Connector_PinSocket_2.54mm',
               f"PinSocket_1x{pair['pins']:02}_P2.54mm_Horizontal", pair['carrier'],
               '2.54 RA SOCKET / FIT CANDIDATE', carrier_xy(pair['Y1_mm'], G['headers']['socket_pad_Z_mm']),
               pair['nets'], rotation=90)
    text(b, 'A3 / PLACEMENT ONLY / NO ROUTING / NOT BUILDABLE', 100, 66, 1)
    text(b, '30mm envelope; 4 SIDE-ACCESS bays for M3 nuts; rear spine Z20.5..32', 100, 69)
    text(b, 'J3/J4: UI reservations only, NOT connected to power/reset circuit', 100, 110)
    text(b, 'Trim socket tails <=2.7mm from F.Cu; keep solder inside module', 100, 114)
    text(b, 'Dashed/contact geometry is drawing-only: enforce keepouts before routing', 100, 118)
    for lo, hi in G['braces']['web_Y_mm']:
        polygon(b, [carrier_xy(y,z) for y,z in [(lo,14.2),(hi,14.2),(hi,30.5),(lo,30.5)]], pcb.Dwgs_User)
    for (_,yc,_), seat in zip(G['panel_spacer_holes_mm'], G['nut_access']['nut_seat_Z_mm']):
        polygon(b, [carrier_xy(y,z) for y,z in [(yc-6,seat),(yc+6,seat),(yc+6,seat+3),(yc-6,seat+3)]], pcb.Dwgs_User)
    stable_ids(b, 'carrier'); pcb.SaveBoard(str(hw/'big_modular.kicad_pcb'), b)

    p = board(); polygon(p, [panel_xy(*q) for q in [(0,0),(9.8,0),(9.8,128.5),(0,128.5)]])
    x,y,w,h,r = G['aperture_XYWHR_mm']; rounded_aperture(p, x+50,y+30,w,h,r)
    for i,(x,y,d) in enumerate(G['rail_holes_mm'],1): hole(p, f'H{i}', panel_xy(x,y),d,contact_radius=3)
    for i,(x,y,d) in enumerate(G['panel_spacer_holes_mm'],3): hole(p, f'H{i}',panel_xy(x,y),d,contact_radius=3.5)
    for ref, key in [('H7','led_XY_diameter_mm'),('H8','reset_XY_diameter_mm')]:
        x,y,d = G[key]; hole(p,ref,panel_xy(x,y),d,contact_radius=0)
    for label,y,size in [('BIG',10.5,.9),('MOD',13,.9),('PWR',33,.8),('PD 9V',54,.8),('USB',74.5,.8),('RESET',86,.8),('A3',118,.8)]:
        text(p,label,*panel_xy(4.9,y),size,pcb.F_SilkS)
    text(p,'2HP / round corner holes X2.42 = X7.50 minus one 5.08mm rail pitch',102,40,.9)
    text(p,'4 x M3 L=10 supports; 6mm studs OR 10mm spacers; holes dia3.2',101,44,.9)
    text(p,'Reset actuator TBD. No panel toggle switch selected.',100,48,.9)
    stable_ids(p,'panel'); pcb.SaveBoard(str(hw/'front_panel.kicad_pcb'),p)

    m = board(); polygon(m,[middle_xy(*q) for q in middle_outline()])
    for i,(x,y,d) in enumerate(G['panel_spacer_holes_mm'],1): hole(m,f'H{i}',middle_xy(x,y),d,contact_radius=3.5)
    for pair in G['headers']['pairs']:
        placed(m,hw,'Connector_PinHeader_2.54mm', f"PinHeader_1x{pair['pins']:02}_P2.54mm_Vertical",
               pair['middle'],'2.54 STRAIGHT MALE / FIT CANDIDATE',
               middle_xy(G['headers']['contact_X_mm'],pair['Y1_mm']),pair['nets'],rotation=180,back=True)
    placed(m,hw,'LED_SMD','LED_0603_1608Metric','D10','POWER LED / MPN TBD',middle_xy(4.9,38),
           {'1':'UI_GND_PENDING','2':'LED_A_PENDING'})
    placed(m,hw,'Resistor_SMD','R_0603_1608Metric','R32','2.2k PROVISIONAL',middle_xy(4.9,42),
           {'1':'UI_P5_PENDING','2':'LED_A_PENDING'})
    placed(m,hw,'Button_Switch_SMD','SW_Push_1P1T_NO_CK_KMR2','SW1','RESET / KMR2 NO / ACTUATOR TBD',
           middle_xy(4.9,91),{'1':'RESET_A_PENDING','2':'RESET_B_PENDING'})
    text(m,'MIDDLE / F.Cu FACES PANEL / B.Cu HEADERS FACE CARRIER',120,38,.8)
    text(m,'8.8 x 100.5 x 1.6; 2.1mm spine beside USB clearance notch',120,42,.8)
    text(m,'D10/R32/SW1/J5/J6 NOT YET IN CIRCUIT SCHEMATIC',119,46,.8)
    text(m,'R32 -> D10 is only a net reservation: NO COPPER / NO POWER',121,50,.8)
    for label,y in [('PWR',24),('K A',40),('RESET',87)]:text(m,label,*middle_xy(4.9,y),.8,pcb.F_SilkS)
    text(m,'SIDE ACCESS: M3 nuts + 5.5AF spanner, head <=12mm wide / <=3mm thick; OUT OF RACK',130,54,.8)
    stable_ids(m,'middle'); pcb.SaveBoard(str(hw/'middle_plate.kicad_pcb'),m)
    (hw/'middle_plate.kicad_pro').write_text(json.dumps({'meta':{'filename':'middle_plate.kicad_pro','version':1}},indent=2)+'\n')
    (hw/'fp-lib-table').write_text((hw/'fp-lib-table').read_text().replace('Unmodified installed GCT USB4105 footprint','Pinned USB and A3 placement-candidate footprints; sourcing unqualified'))
    (output/'assembly-geometry.json').write_text(json.dumps(G,indent=2)+'\n')
    # Source manifest includes unchanged electrical documents, not only boards.
    sources = [q for q in (ROOT/'hardware').rglob('*') if q.is_file() and q.suffix not in ('.lck','.kicad_prl')]
    sources += [ROOT/'BOM.csv',ROOT/'docs/pin-net-audit.json']
    (output/'source-manifest.json').write_text(json.dumps({
        'status':'placement candidate / not electrically synchronized / not fabrication ready',
        'common_tool_limit':'pcb inspect: 3D models, embedded files and images are unsupported dependencies; fail closed',
        'source_sha256':{str(q.relative_to(ROOT)):hashlib.sha256(q.read_bytes()).hexdigest() for q in sources},
        'new_refs':['J3','J4','J5','J6','D10','R32','SW1'], 'routing_performed':False},indent=2)+'\n')
    print('Created NEW three-board placement candidate:',output)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True,help='NEW directory; existing paths are rejected')
    build(parser.parse_args().output)
