"""Conservative nominal M3 assembly envelopes, NOT tolerance/strength analysis.

The caller supplies the ACTUAL native carrier outline in assembly YZ. No CAD
package is required. Orthogonal polygons are decomposed into solid prisms; the
wrench is a swept bounding box (including side-entry handle), not just a nut dot.
"""
import math


def overlap(a, b):
    """Positive-volume overlap; contact between intended mating faces is allowed."""
    return all(min(aa[1], bb[1]) - max(aa[0], bb[0]) > 1e-7 for aa, bb in zip(a, b))


def prisms(outline, x_range):
    ys = sorted({p[0] for p in outline})
    for lo, hi in zip(ys, ys[1:]):
        mid = (lo+hi)/2
        zs = sorted(a[1] for a,b in zip(outline, outline[1:]+outline[:1])
                    if a[1] == b[1] and min(a[0],b[0]) < mid < max(a[0],b[0]))
        assert len(zs) % 2 == 0
        for z0, z1 in zip(zs[::2], zs[1::2]):
            yield [x_range, [lo,hi], [z0,z1]]


def verify_access(g, carrier_polygon, header_y_rows):
    h = g['spacers']; a = g['nut_access']; br = g['braces']
    assert h['thread'] == 'M3' and h['length_mm'] == 10 and h['male_thread_length_mm'] == 6
    assert g['middle_Z_mm'] == [11.6,13.2]
    assert a['spanner_AF_mm'] == 5.5 and a['tool_head_Y_width_max_mm'] >= 12
    assert a['tool_thickness_max_mm'] >= 3
    assert br['front_flange_mm'] == h['brace_seat_thickness_mm'] == 1.0
    assert h['female_usable_depth_min_mm'] >= 5
    carrier = list(prisms(carrier_polygon, g['carrier_X_mm']))
    obstacles = [(f'carrier solid {i}', box) for i,box in enumerate(carrier)]
    for i,ys in enumerate(header_y_rows):
        # Contains BOTH mated headers, tails and a conservative solder envelope.
        obstacles.append((f'mated soldered header pair {i+1}',
                          [[.27,5.71], [min(ys)-1.5,max(ys)+1.5], [13.2,26.77]]))
    obstacles.append(('USB shell', [[3.17,6.48],[59.78,68.72],[.8,8.4]]))
    for i,(fy,wy) in enumerate(zip(br['foot_Y_mm'],br['web_Y_mm'])):
        obstacles += [(f'brace {i+1} foot', [br['foot_X_mm'],fy,[13.2,14.2]]),
                      (f'brace {i+1} upright', [br['web_X_mm'],wy,[14.2,30.5]])]
    rows=[]
    for i,((x,y,d),seat) in enumerate(zip(g['panel_spacer_holes_mm'],a['nut_seat_Z_mm'])):
        assert d == 3.2
        flange = br['front_flange_mm'] if y in br['Y_centres_mm'] else 0
        assert math.isclose(seat,13.2+flange+h['washer_thickness_mm'])
        tip = 11.6+h['male_thread_length_mm']
        exposure = tip-seat-h['nut_height_max_mm']
        plain_exposure = 18-seat-h['nut_height_max_mm']
        assert exposure >= .5-1e-7, ('not enough stud for full nut',i)
        assert math.isclose(exposure,h['male_stud_exposure_past_nut_mm'][i])
        assert math.isclose(plain_exposure,h['plain_spacer_exposure_past_nut_mm'][i])
        assert math.isclose(h['male_stud_tip_Z_mm'],tip)
        assert math.isclose(h['plain_spacer_bolt_tip_Z_mm'],18)
        radius = h['nut_AF_max_mm']/math.sqrt(3)  # maximum ideal sharp-corner hex
        assert 0 < x-radius < x+radius < 9.8
        body_radius = max(h['max_round_OD_mm']/2,h['max_hex_AF_mm']/math.sqrt(3))
        assert .5 <= x-body_radius and x+body_radius <= 9.3
        assert 10 < y-body_radius and y+body_radius < 118.5
        # Spacer body is in the FRONT gap; must not hit the retained USB tongue.
        body = [[x-body_radius,x+body_radius],[y-body_radius,y+body_radius],[1.6,11.6]]
        # Rear nut can rotate through 360 degrees. Include washer and worst bolt tip.
        nut = [[x-3.5,x+3.5],[y-3.5,y+3.5],[13.2+flange,18]]
        half_width = a['tool_head_Y_width_max_mm']/2
        tool = [a['tool_X_mm'],[y-half_width,y+half_width],[seat,seat+a['tool_thickness_max_mm']]]
        for label,obstacle in obstacles:
            assert not overlap(body,obstacle), ('spacer body collision',i,label)
            # The same brace foot is the intended seating surface, not an obstruction.
            assert not overlap(nut,obstacle), ('nut/washer/bolt collision',i,label)
            assert not overlap(tool,obstacle), ('side spanner access blocked',i,label)
        front_reach = 6-1.6
        rear_len = 8 if flange else 6
        rear_reach = rear_len-1.6-flange-.5
        ff_gap = 10-front_reach-rear_reach
        assert ff_gap >= .7-1e-7 and rear_reach <= h['female_usable_depth_min_mm']
        assert math.isclose(ff_gap,h['female_female_opposing_tip_gaps_mm'][i])
        rows.append({'Y_mm':y, 'nut_seat_Z_mm':seat, 'stud_exposure_mm':round(exposure,4),
                     'plain_spacer_exposure_mm':round(plain_exposure,4),
                     'female_female_tip_gap_mm':round(ff_gap,4),
                     'spanner_swept_box_XYZ_mm':tool, 'collision_free_nominal':True})
    return {'positions':rows, 'tool':'5.5 AF open-end, head <=12mm wide, <=3mm thick',
            'service_condition':'OUT OF RACK, side +X access, carrier soldered AND mated',
            'qualification':'Nominal bounding-box regression only; physical samples/tool/tolerances untested'}
