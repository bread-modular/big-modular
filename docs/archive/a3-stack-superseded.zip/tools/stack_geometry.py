"""A3 placement-only contract. Millimetres, panel origin, +Z into case.

User hardware: M3, 10mm body / 6mm male thread, or 10mm spacers.
Envelopes below are design limits, NOT measurements of the user's actual parts.
J1 and the circuit stay unchanged. No routing or fabrication qualification.
"""
from copy import deepcopy

GEOMETRY = {
    'revision': 'A3 M3 / placement-only / no routing',
    'panel_mm': [9.8, 128.5, 1.6],
    'rail_holes_mm': [[2.42, 3, 3.2], [2.42, 125.5, 3.2]],
    'rail_compatibility': 'Left-corner round holes: X=7.50-5.08=2.42, common Doepfer-phase fixed strips or sliding nuts',
    'rail_head_note': '6mm heads overhang the left panel edge by 0.58mm; check neighbour. Diameter <=4.6mm avoids nominal overhang. No countersink.',
    'panel_spacer_holes_mm': [[4.9, y, 3.2] for y in [17.5, 50, 78.5, 111]],
    'middle_X_mm': [0.5, 9.3], 'middle_Y_mm': [14, 114.5], 'middle_Z_mm': [11.6, 13.2],
    'middle_notch_XY_mm': [0.5, 7.2, 56.5, 72.0],
    'carrier_X_mm': [1.57, 3.17], 'carrier_Y_mm': [14, 114.5], 'carrier_Z_mm': [2, 32],
    'carrier_body_front_Z_mm': 15.0,
    'carrier_access_bays_YZ_mm': [[14,24,20.5], [43.5,56.5,20.5], [72,85,20.5], [104.5,114.5,20.5]],
    'carrier_tongue_Y_mm': [57.5, 71.0],
    'carrier_holes_YZ_mm': [[40, 25.2], [89.5, 25.2], [45, 28], [83.5, 28]],
    'aperture_XYWHR_mm': [2.725, 59.35, 4.2, 9.8, 0.6],
    'mouth_axis_XYZ_mm': [4.9, 64.25, 0.8],
    'led_XY_diameter_mm': [4.9, 38, 2.4],
    'reset_XY_diameter_mm': [4.9, 91, 3.2],
    'spacers': {
        'quantity': 4, 'length_mm': 10.0, 'thread': 'M3', 'male_thread_length_mm': 6.0,
        'max_hex_AF_mm': 6.0, 'max_round_OD_mm': 7.0, 'panel_screw': 'M3 x 6',
        'female_usable_depth_min_mm': 5.0, 'panel_engagement_mm': 4.4,
        'nut_AF_max_mm': 5.5, 'nut_height_max_mm': 2.4,
        'washer_OD_max_mm': 7.0, 'washer_thickness_mm': 0.5,
        'brace_seat_thickness_mm': 1.0,
        'male_stud_tip_Z_mm': 17.6,
        'male_stud_exposure_past_nut_mm': [1.5, 0.5, 0.5, 1.5],
        'plain_spacer_bolt': 'M3 x 18 (fully threaded)',
        'plain_spacer_bolt_tip_Z_mm': 18.0,
        'plain_spacer_exposure_past_nut_mm': [1.9, 0.9, 0.9, 1.9],
        'female_female_rear_screws': ['M3 x 6', 'M3 x 8', 'M3 x 8', 'M3 x 6'],
        'female_female_opposing_tip_gaps_mm': [1.7, 0.7, 0.7, 1.7],
        'status': 'Stud points rearward through middle. Standard plain hex nuts, not nyloc. Body OD/AF, tapped depth and actual tool must be measured.'
    },
    'nut_access': {
        'direction': 'Side entry from +X, module OUT of rack; assembled carrier remains plugged in',
        'spanner_AF_mm': 5.5, 'tool_head_Y_width_max_mm': 12.0, 'tool_thickness_max_mm': 3.0,
        'tool_X_mm': [-1.1, 30.0],
        'nut_seat_Z_mm': [13.7, 14.7, 14.7, 13.7],
        'status': 'Four open side bays reserve wrench/head + handle access after soldering. Hold/re-index nut, turn front bolt; NOT rear socket-driver access or in-rack service.'
    },
    'headers': {
        'pitch_mm': 2.54, 'contact_X_mm': 4.44, 'socket_contact_height_mm': 1.27,
        'socket_pad_Z_mm': 25.77, 'socket_mouth_Z_mm': 15.74,
        'socket_body_depth_mm': 8.51, 'socket_pad_to_mouth_mm': 10.03,
        'male_body_mm': 2.54, 'male_mating_length_mm': 6.0,
        'carrier_tail_max_mm': 2.7, 'solder_allowance_mm': 0.2,
        'pairs': [
            {'carrier': 'J3', 'middle': 'J5', 'pins': 4, 'Y1_mm': 26.0,
             'nets': {'1': 'UI_P5_PENDING', '2': 'UI_GND_PENDING', '3': 'UI_GND_PENDING', '4': 'UI_P5_PENDING'}},
            {'carrier': 'J4', 'middle': 'J6', 'pins': 3, 'Y1_mm': 96.0,
             'nets': {'1': 'RESET_A_PENDING', '2': 'RESET_B_PENDING', '3': ''}},
        ],
        'status': 'Generic KiCad envelopes only; exact mating pair/engagement/tolerances unselected. Trim socket tails.'
    },
    'braces': {
        'quantity': 2, 'foot_X_mm': [0.5, 9.3], 'web_X_mm': [3.17, 8.97],
        'Z_mm': [13.2, 30.5], 'front_flange_mm': 1.0,
        'front_screw_X_mm': 4.9, 'Y_centres_mm': [50, 78.5],
        'foot_Y_mm': [[37,54], [74.5,92.5]], 'web_Y_mm': [[37,43], [86.5,92.5]],
        'side_hole_Y_mm': [40,89.5], 'side_hole_Z_mm': 25.2,
        'side_bolt': 'M2 x 8, head <=1.2 high / <=3.8 diameter (retained carrier brace hardware, NOT panel standoffs)',
        'nut': 'M2 captive hex, AF <=4.0, thickness <=1.6',
        'nut_pocket_X_mm': [7.17, 8.97],
        'status': 'Open-sided original fit prototype. 1mm M3 seat plus <=0.5mm washer leaves 0.5mm stud beyond full M3 nut. Thin seat/creep/strength need testing.'
    },
    'harness_envelope_XYZ_mm': [[0.4, 9.4], [40, 75], [34, 50]],
    'harness_status': '50mm front-plane depth is a provisional cable budget, NOT a certified case-depth requirement',
    'reset_status': 'NO switch footprint and access hole only; no actuator selected, no reset circuitry connected',
    'electrical_status': 'J1 unchanged; D10/R32/SW1/J3..J6 are PCB-only reservations, NOT in the 88-part circuit schematic/BOM',
    'status': 'NOT FOR FABRICATION; no routing, power-layout fit, electrical reset, thermal or mechanical qualification'
}


def geometry():
    return deepcopy(GEOMETRY)


def carrier_xy(y, z):
    return (round(y + 35.75, 5), round(104.275 - z, 5))


def panel_xy(x, y):
    return (round(x + 50, 5), round(y + 30, 5))


def middle_xy(x, y):
    return (round(x + 80, 5), round(y + 30, 5))


def carrier_outline():
    # Front-open wrench bays; continuous rear spine Z20.5..32 remains.
    return [(14,20.5), (24,20.5), (24,15), (43.5,15), (43.5,20.5),
            (56.5,20.5), (56.5,15), (57.5,15), (57.5,2), (71,2),
            (71,15), (72,15), (72,20.5), (85,20.5), (85,15),
            (104.5,15), (104.5,20.5), (114.5,20.5), (114.5,32), (14,32)]


def middle_outline():
    return [(0.5,14), (9.3,14), (9.3,114.5), (0.5,114.5),
            (0.5,72), (7.2,72), (7.2,56.5), (0.5,56.5)]
