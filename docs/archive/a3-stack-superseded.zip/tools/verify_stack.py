#!/usr/bin/env python3
"""Independent native A3 fit/placement regression, NOT DRC or fit qualification."""
from pathlib import Path
import argparse
import json
import math
import pcbnew as pcb
from m3_fit import verify_access

ROOT = Path(__file__).resolve().parents[1]


def mm(n): return round(pcb.ToMM(n), 5)
def xy(item): return (mm(item.GetPosition().x), mm(item.GetPosition().y))


def verify(hardware=ROOT/'hardware', geometry_file=ROOT/'docs/assembly-geometry.json'):
    g = json.loads(geometry_file.read_text())
    boards = {name: pcb.LoadBoard(str(hardware/(name+'.kicad_pcb')))
              for name in ['big_modular','middle_plate','front_panel']}
    allowed = {'big_modular': {'J1','J3','J4','H1','H2','H3','H4'},
               'middle_plate': {'D10','R32','SW1','J5','J6','H1','H2','H3','H4'},
               'front_panel': {f'H{i}' for i in range(1,9)}}
    fps = {}; result = {'boards':{}, 'fabrication_ready':False}
    for name,b in boards.items():
        fps[name] = {f.GetReference():f for f in b.GetFootprints()}
        assert set(fps[name]) == allowed[name], (name, 'unexpected inventory')
        assert not list(b.GetTracks()) and not list(b.Zones()), (name,'routing is forbidden')
        assert all(d.GetLayer() not in [pcb.F_Cu,pcb.B_Cu] for d in b.GetDrawings())
        assert math.isclose(pcb.ToMM(b.GetDesignSettings().GetBoardThickness()),1.6)
        edge = [d for d in b.GetDrawings() if d.GetLayer()==pcb.Edge_Cuts]
        assert len(edge) == {'front_panel':12,'middle_plate':8,'big_modular':20}[name]
        points=[(mm(v.x),mm(v.y)) for d in edge for v in [d.GetStart(),d.GetEnd()]]
        size=(round(max(x for x,y in points)-min(x for x,y in points),5),
              round(max(y for x,y in points)-min(y for x,y in points),5))
        assert size == {'big_modular':(100.5,30),'middle_plate':(8.8,100.5),'front_panel':(9.8,128.5)}[name]
        result['boards'][name+'.kicad_pcb']={'footprints':sorted(fps[name]),'outline_envelope_mm':size,
            'tracks':0,'vias':0,'zones':0,'copper_graphics':0,'edge_primitives':len(edge)}
    def npth(name,ref,x,y,dx,dy=None):
        f=fps[name][ref]; pads=list(f.Pads()); assert len(pads)==1
        p=pads[0]; assert p.GetAttribute()==pcb.PAD_ATTRIB_NPTH
        assert xy(p)==(x,y), (name,ref,xy(p),(x,y))
        assert (mm(p.GetDrillSize().x),mm(p.GetDrillSize().y))==(dx,dy or dx)
    for i,(y,z) in enumerate([(40,25.2),(89.5,25.2),(45,28),(83.5,28)],1):
        npth('big_modular',f'H{i}',y+35.75,round(104.275-z,5),2.2)
    assert g['carrier_holes_YZ_mm']==[[40,25.2],[89.5,25.2],[45,28],[83.5,28]]
    for i,y in enumerate([3,125.5],1):npth('front_panel',f'H{i}',52.42,y+30,3.2)
    for i,y in enumerate([17.5,50,78.5,111],1):
        npth('middle_plate',f'H{i}',84.9,y+30,3.2)
        npth('front_panel',f'H{i+2}',54.9,y+30,3.2)
    npth('front_panel','H7',54.9,68,2.4);npth('front_panel','H8',54.9,121,3.2)
    assert xy(fps['middle_plate']['D10'])==(84.9,68)
    assert xy(fps['middle_plate']['SW1'])==(84.9,121)
    assert all(fps['middle_plate'][r].GetLayer()==pcb.F_Cu for r in ['D10','R32','SW1'])
    # Retained USB native datum, library, pad/net membership and normal mating axis.
    usb=fps['big_modular']['J1']; assert xy(usb)==(100,99.8) and usb.GetOrientationDegrees()==0
    assert usb.GetFPID().GetLibItemName()=='USB_C_Receptacle_GCT_USB4105-xx-A_16P_TopMnt_Horizontal'
    pin_audit=json.loads((ROOT/'docs/pin-net-audit.json').read_text())['J1']
    for pad in usb.Pads():
        assert pad.GetNetname()==(pin_audit.get(pad.GetNumber()) or '')
    assert math.isclose(104.275-99.8-3.675,.8,abs_tol=1e-8)
    assert math.isclose(3.17+1.73,4.9,abs_tol=1e-8)
    # Back-side flipping can REVERSE the pin order: verify native pad coordinates,
    # not merely equal anchors or matching labels. Both rows must run down in Y.
    mappings=[]
    for cr,mr,y1,nets in [
        ('J3','J5',26,['UI_P5_PENDING','UI_GND_PENDING','UI_GND_PENDING','UI_P5_PENDING']),
        ('J4','J6',96,['RESET_A_PENDING','RESET_B_PENDING',''])]:
        cf=fps['big_modular'][cr];mf=fps['middle_plate'][mr]
        assert cf.GetLayer()==pcb.F_Cu and cf.GetOrientationDegrees()==90
        assert mf.GetLayer()==pcb.B_Cu and abs(mf.GetOrientationDegrees())==180
        cp={p.GetNumber():p for p in cf.Pads()};mp={p.GetNumber():p for p in mf.Pads()}
        assert len(cp)==len(mp)==len(nets)
        for i,net in enumerate(nets,1):
            c=cp[str(i)];m=mp[str(i)];want_y=round(y1+(i-1)*2.54,5)
            assert xy(c)==(round(want_y+35.75,5),78.505)
            assert xy(m)==(84.44,round(want_y+30,5)), ('mirrored/reversed row',mr,i,xy(m))
            assert c.GetNetname()==m.GetNetname()==net
            mappings.append({'carrier':f'{cr}.{i}','middle':f'{mr}.{i}',
                             'axis_XY_mm':[4.44,want_y],'net':net or None})
    # Isolated front circuit intent: LED has a series resistance, reset is not
    # grounded, not wired to RUN/SHDN and cannot short PG_PERMIT to RTN.
    for ref,nets in {'D10':{'1':'UI_GND_PENDING','2':'LED_A_PENDING'},
                     'R32':{'1':'UI_P5_PENDING','2':'LED_A_PENDING'},
                     'SW1':{'1':'RESET_A_PENDING','2':'RESET_B_PENDING'}}.items():
        for p in fps['middle_plate'][ref].Pads(): assert p.GetNetname()==nets[p.GetNumber()]
    assert all(p.GetNetname() not in ['GND','RTN','EF_ENABLE','PG_PERMIT','P5']
               for r in ['J3','J4'] for p in fps['big_modular'][r].Pads())
    # Read actual edge endpoints to reject a forgotten notch or unchanged carrier.
    def edge_points(name):
        return {(mm(v.x),mm(v.y)) for d in boards[name].GetDrawings() if d.GetLayer()==pcb.Edge_Cuts
                for v in [d.GetStart(),d.GetEnd()]}
    expected_carrier = [(14,20.5),(24,20.5),(24,15),(43.5,15),(43.5,20.5),
        (56.5,20.5),(56.5,15),(57.5,15),(57.5,2),(71,2),(71,15),(72,15),
        (72,20.5),(85,20.5),(85,15),(104.5,15),(104.5,20.5),(114.5,20.5),(114.5,32),(14,32)]
    assert edge_points('big_modular')=={(round(y+35.75,5),round(104.275-z,5)) for y,z in expected_carrier}
    # Check actual connectivity, not just endpoints; protects the wrench bays.
    actual_edges = {frozenset(((mm(d.GetStart().x),mm(d.GetStart().y)),
                              (mm(d.GetEnd().x),mm(d.GetEnd().y))))
                    for d in boards['big_modular'].GetDrawings() if d.GetLayer()==pcb.Edge_Cuts}
    wanted_edges = {frozenset(( (round(a[0]+35.75,5),round(104.275-a[1],5)),
                               (round(b[0]+35.75,5),round(104.275-b[1],5)) ))
                    for a,b in zip(expected_carrier,expected_carrier[1:]+expected_carrier[:1])}
    assert actual_edges == wanted_edges
    assert edge_points('middle_plate')=={(x+80,y+30) for x,y in
        [(.5,14),(9.3,14),(9.3,114.5),(.5,114.5),(.5,72),(7.2,72),(7.2,56.5),(.5,56.5)]}
    # Nominal 3D checks; all native hole/pad transforms above are independent.
    assert g['middle_Z_mm']==[11.6,13.2] and g['carrier_Z_mm']==[2,32]
    assert math.isclose(13.2+2.54,15.74) and math.isclose(25.77-10.03,15.74)
    assert math.isclose(3.17+1.27,4.44) and 3.17-2.7-.2 > 0
    assert 1.57-1.2 > 0 and 1.57+8 < 9.8  # Retained M2 brace bolt only.
    assert 7.2 > 6.48 and 56.5 < 57.5 < 71 < 72
    assert math.isclose(9.3-7.2,2.1) and math.isclose(32-1.6,30.4)
    assert g['rail_holes_mm']==[[2.42,3,3.2],[2.42,125.5,3.2]]
    assert math.isclose(7.5-2.42,5.08) # One pitch left, SAME fixed-strip phase.
    assert math.isclose(2.42-1.6,.82) # Round-hole edge web, not centred slots.
    ys = [[m['axis_XY_mm'][1] for m in mappings if m['middle'].startswith(r+'.')] for r in ['J5','J6']]
    access = verify_access(g, expected_carrier, ys)
    result['mechanics']={'actual_NPTH_geometry_checks':16,'mating_pin_axis_checks':len(mappings),
        'connector_mapping':mappings,'port_axis_mm':[4.9,64.25,.8],'insertion_vector':[0,0,1],
        'carrier_depth_mm':30,'rear_edge_Z_mm':32,'PCB_depth_behind_panel_mm':30.4,
        'provisional_cable_back_Z_mm':50,'middle_spine_mm':2.1,
        'rail_mount':'round left-corner holes, X2.42 = X7.50 - 5.08; common fixed-strip phase',
        'M3_access':access,
        'status':'Nominal fit regressions only; actual hardware/tool, tolerances, strength and circuit integration unqualified'}
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--hardware',type=Path,default=ROOT/'hardware')
    parser.add_argument('--geometry',type=Path,default=ROOT/'docs/assembly-geometry.json')
    parser.add_argument('--output',type=Path)
    args=parser.parse_args();result=verify(args.hardware,args.geometry)
    if args.output:
        with args.output.open('x') as f: f.write(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
